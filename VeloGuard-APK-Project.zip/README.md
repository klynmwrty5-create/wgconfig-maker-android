# VeloGuard VPN — پروژه آماده ساخت APK اندروید (v3.4.1)

این مخزن شامل سورس کامل اپلیکیشن اندروید **VeloGuard** است که رابط کاربری شیشه‌ای بهینه (`app/src/main/assets/www/index.html`) را از طریق پل ارتباطی `AndroidVpn` به هسته‌های بومی زیر متصل می‌کند:
- **Aether v2.4.0** (`MASQUE H3 / H2`, `MIM`, `Gool`, `WARP WG`)
- **Psiphon Core** (`psiphon-tunnel-core` همراه با `cdn` IP-fronting و زنجیره‌های ترکیبی)
- **WireGuard (`GoBackend`)** برای کانفیگ‌های شخصی `.conf` و QR Code
- **حالت گیم Full-UDP (`PUBG / CODM`)** با مسیر کامل UDP، اسکن کم‌پینگ‌ترین IP (`thorough`) و بافر بزرگ `hev-socks5-tunnel`

## ساخت خودکار APK با GitHub Actions
1. فایل‌های داخل `VeloGuard-APK-Project.zip` را استخراج کرده و در روت مخزن گیت‌هاب آپلود (Push) کنید (یا فایل زیپ به همراه پوشه `.github/workflows/build-apk.yml` را قرار دهید).
2. از تب **Actions** روی ورک‌فلو **`Build VeloGuard APK`** کلیک کنید و دکمه **Run workflow** را بزنید (یا با هر Push به‌صورت خودکار اجرا می‌شود).
3. پس از پایان بیلد، از بخش **Artifacts** فایل **`VeloGuard-APK`** را دانلود و نسخه `release` را روی گوشی نصب کنید.
