package com.tunweb.wireguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import hev.htproxy.TProxyService
import org.json.JSONObject
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

class AetherVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.tunweb.wireguard.AETHER_START"
        const val ACTION_STOP = "com.tunweb.wireguard.AETHER_STOP"
        const val ACTION_EVENT = "com.tunweb.wireguard.AETHER_EVENT"

        const val EXTRA_CONFIG_JSON = "config_json"
        const val EXTRA_PROTOCOL = "protocol"
        const val EXTRA_SCAN = "scan"
        const val EXTRA_NOIZE = "noize"
        const val EXTRA_MTU = "mtu"
        const val EXTRA_FRAGMENT = "fragment"
        const val EXTRA_DNS = "dns"
        const val EXTRA_EXCLUDED_APPS = "excluded_apps"
        const val EXTRA_PSIPHON_REGION = "psiphon_region"
        const val EXTRA_PSIPHON_CDN = "psiphon_cdn"
        const val EXTRA_STEALTH_TLS = "stealth_tls"
        const val EXTRA_ECH_AUTO = "ech_auto"
        const val EXTRA_DIRECT_IR = "direct_ir"
        const val EXTRA_AVOID_IR_EXIT = "avoid_ir_exit"
        const val EXTRA_GAME_MODE = "game_mode"

        const val EVENT_TYPE = "type"
        const val EVENT_STATE = "state"
        const val EVENT_MESSAGE = "message"
        const val EVENT_RX = "rx"
        const val EVENT_TX = "tx"

        private const val CHANNEL_ID = "novaguard_aether_vpn"
        private const val NOTIF_ID = 8018

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        @Volatile
        var currentState: String = "disconnected"
            private set

        @Volatile
        var isUiVisible: Boolean = true

        @Volatile
        var activeSocksPort: Int = 1819
            private set

        fun clearAetherCache(context: Context): Boolean {
            return try {
                val dir = File(context.filesDir, "aether")
                if (dir.exists()) {
                    dir.deleteRecursively()
                }
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    data class AetherLaunchConfig(
        val protocol: String = "wg",
        val transport: String = "h3", // h3 | h2
        val connectionMode: String = "vpn", // vpn | vpn_tcp | proxy
        val scan: String = "turbo", // turbo | balanced | thorough | verified | ironclad
        val noize: String = "default", // default | off | light | firewall | balanced | gfw | aggressive
        val ipVersion: String = "4", // 4 | 6 | dual
        val quickReconnect: Boolean = true,
        val rescanOnDrop: Boolean = true,
        val keepAwake: Boolean = true,
        val customEndpoint: String = "",
        val upstreamProxy: String = "",
        val blockList: String = "",
        val directList: String = "",
        val dns: String = "1.1.1.1,1.0.0.1",
        val excludedApps: String = "",
        val psiphonRegion: String = "",
        val psiphonCdn: Boolean = false,
        val stealthTls: Boolean = false,
        val echAuto: Boolean = false,
        val directIr: Boolean = false,
        val avoidIrExit: Boolean = false,
        val gameMode: Boolean = false,
        val socksPort: Int = 1819,
        val shareSocksLan: Boolean = false,
        val httpProxyEnabled: Boolean = false,
        val perfProfile: String = "auto", // auto | low | medium | high
        val extraArgs: String = "",
        val mtu: Int = 1280,
        val tcpBufferKb: Int = 256,
        val fragmentH2: Boolean = false
    )

    private val workerExecutor = Executors.newSingleThreadExecutor()
    private val statsScheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var statsTask: ScheduledFuture<*>? = null

    private var aetherProcess: Process? = null
    private var tunInterface: ParcelFileDescriptor? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val stopping = AtomicBoolean(false)
    private val tunnelReadyFlag = AtomicBoolean(false)

    @Volatile
    private var lastErrorLine: String = ""
    private var lastSentRx: Long = -1L
    private var lastSentTx: Long = -1L
    private var activeProxyOnly: Boolean = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAetherTunnel("اتصال متوقف شد.")
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val cfg = parseLaunchConfig(intent)
                createNotificationChannel()
                val modeTag = when {
                    cfg.connectionMode == "proxy" -> "Proxy SOCKS5:${cfg.socksPort}"
                    cfg.gameMode -> "Gaming Full-UDP"
                    else -> cfg.protocol.uppercase()
                }
                val notif = buildNotification("VeloGuard ($modeTag) در حال اتصال...")
                try {
                    if (Build.VERSION.SDK_INT >= 34) {
                        startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                    } else {
                        startForeground(NOTIF_ID, notif)
                    }
                } catch (_: Exception) {
                }
                startAetherTunnel(cfg)
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun parseLaunchConfig(intent: Intent): AetherLaunchConfig {
        val rawJson = intent.getStringExtra(EXTRA_CONFIG_JSON)
        if (!rawJson.isNullOrBlank()) {
            try {
                val o = JSONObject(rawJson)
                return AetherLaunchConfig(
                    protocol = o.optString("protocol", "wg"),
                    transport = o.optString("transport", "h3"),
                    connectionMode = o.optString("connectionMode", "vpn"),
                    scan = o.optString("scan", "turbo"),
                    noize = o.optString("noize", "default"),
                    ipVersion = o.optString("ipVersion", "4"),
                    quickReconnect = o.optBoolean("quickReconnect", true),
                    rescanOnDrop = o.optBoolean("rescanOnDrop", true),
                    keepAwake = o.optBoolean("keepAwake", true),
                    customEndpoint = o.optString("customEndpoint", "").trim(),
                    upstreamProxy = o.optString("upstreamProxy", "").trim(),
                    blockList = o.optString("blockList", "").trim(),
                    directList = o.optString("directList", "").trim(),
                    dns = o.optString("dns", "1.1.1.1,1.0.0.1").trim(),
                    excludedApps = o.optString("excludedApps", "").trim(),
                    psiphonRegion = o.optString("psiphonRegion", "").trim(),
                    psiphonCdn = o.optBoolean("psiphonCdn", false),
                    stealthTls = o.optBoolean("stealthTls", false),
                    echAuto = o.optBoolean("echAuto", false),
                    directIr = o.optBoolean("directIr", false),
                    avoidIrExit = o.optBoolean("avoidIrExit", false),
                    gameMode = o.optBoolean("gameMode", false),
                    socksPort = o.optInt("socksPort", 1819).coerceIn(1024, 65000),
                    shareSocksLan = o.optBoolean("shareSocksLan", false),
                    httpProxyEnabled = o.optBoolean("httpProxyEnabled", false),
                    perfProfile = o.optString("perfProfile", "auto").trim().lowercase(),
                    extraArgs = o.optString("extraArgs", "").trim(),
                    mtu = o.optInt("mtu", 1280).coerceIn(1280, 9000),
                    tcpBufferKb = o.optInt("tcpBufferKb", 256).coerceIn(16, 4096),
                    fragmentH2 = o.optBoolean("fragmentH2", false)
                )
            } catch (_: Exception) {
            }
        }
        val proto = intent.getStringExtra(EXTRA_PROTOCOL) ?: "wg"
        val frag = intent.getBooleanExtra(EXTRA_FRAGMENT, false)
        return AetherLaunchConfig(
            protocol = proto,
            transport = if (frag || proto == "masque_h2") "h2" else "h3",
            scan = intent.getStringExtra(EXTRA_SCAN) ?: "turbo",
            noize = intent.getStringExtra(EXTRA_NOIZE) ?: "default",
            mtu = intent.getIntExtra(EXTRA_MTU, 1280).coerceIn(1280, 9000),
            dns = intent.getStringExtra(EXTRA_DNS) ?: "1.1.1.1,1.0.0.1",
            excludedApps = intent.getStringExtra(EXTRA_EXCLUDED_APPS) ?: "",
            psiphonRegion = intent.getStringExtra(EXTRA_PSIPHON_REGION) ?: "",
            psiphonCdn = intent.getBooleanExtra(EXTRA_PSIPHON_CDN, false),
            stealthTls = intent.getBooleanExtra(EXTRA_STEALTH_TLS, false),
            echAuto = intent.getBooleanExtra(EXTRA_ECH_AUTO, false),
            directIr = intent.getBooleanExtra(EXTRA_DIRECT_IR, false),
            avoidIrExit = intent.getBooleanExtra(EXTRA_AVOID_IR_EXIT, false),
            gameMode = intent.getBooleanExtra(EXTRA_GAME_MODE, false),
            fragmentH2 = frag
        )
    }

    private fun tokenizeArgs(raw: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quote: Char? = null
        for (ch in raw) {
            when {
                quote != null -> {
                    if (ch == quote) quote = null else sb.append(ch)
                }
                ch == '"' || ch == '\'' -> quote = ch
                ch.isWhitespace() -> {
                    if (sb.isNotEmpty()) {
                        out.add(sb.toString())
                        sb.clear()
                    }
                }
                else -> sb.append(ch)
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    private fun resolveReachableWarpApiIp(): String? {
        return try {
            val resolved = InetAddress.getByName("api.devices.cloudflare.com").hostAddress ?: ""
            val isPoisoned = resolved.isBlank() ||
                resolved.startsWith("10.") ||
                resolved.startsWith("127.") ||
                resolved.startsWith("0.") ||
                resolved.startsWith("192.168.")
            if (!isPoisoned) return null
            emitLog("[MCI/DNS] api.devices.cloudflare.com poisoned ($resolved); probing direct Cloudflare API edge...")
            val candidates = listOf("104.24.4.6", "104.18.0.6", "162.159.137.105")
            for (ip in candidates) {
                try {
                    Socket().use { s ->
                        s.connect(InetSocketAddress(ip, 443), 1500)
                        emitLog("[MCI/DNS] Using direct WARP API edge $ip:443")
                        return ip
                    }
                } catch (_: Exception) {
                }
            }
            "104.24.4.6"
        } catch (_: Exception) {
            emitLog("[MCI/DNS] DNS lookup failed; using direct WARP API edge 104.24.4.6")
            "104.24.4.6"
        }
    }

    private fun buildAetherCommand(
        aetherBin: File,
        psiphonBin: File,
        workDir: File,
        cfg: AetherLaunchConfig,
        protocol: String,
        scan: String,
        quickReconnect: Boolean,
        sniOverride: String? = null,
        forceCdn: Boolean = false,
        forceH2: Boolean = false,
        useEch: Boolean = false,
        noizeOverride: String? = null,
        cdnSetsOverride: String? = null,
        apiAddressOverride: String? = null,
        isCellular: Boolean = false
    ): List<String> {
        val psiphonDataDir = File(workDir, "psiphon").apply { mkdirs() }
        val bindHost = if (cfg.shareSocksLan) "0.0.0.0" else "127.0.0.1"
        val socksBind = "$bindHost:${cfg.socksPort}"

        fun appendPsiphonFlags(cmd: MutableList<String>) {
            if (psiphonBin.exists()) {
                cmd.add("--psiphon-bin")
                cmd.add(psiphonBin.absolutePath)
            }
            cmd.add("--psiphon-dir")
            cmd.add(psiphonDataDir.absolutePath)
            if (cfg.psiphonRegion.isNotBlank() && cfg.psiphonRegion != "AUTO") {
                cmd.add("--psiphon-region")
                cmd.add(cfg.psiphonRegion)
            }
            if (forceCdn || cfg.psiphonCdn) {
                cmd.add("--psiphon-mode")
                cmd.add("cdn")
                if (!cdnSetsOverride.isNullOrBlank()) {
                    cmd.add("--psiphon-cdn-sets")
                    cmd.add(cdnSetsOverride)
                }
            } else {
                cmd.add("--psiphon-mode")
                cmd.add("auto")
            }
        }

        fun appendRoutingAndProxy(cmd: MutableList<String>) {
            if (cfg.httpProxyEnabled) {
                val httpPort = cfg.socksPort + 1
                cmd.add("--http-proxy")
                cmd.add("$bindHost:$httpPort")
            }
            if (cfg.upstreamProxy.isNotBlank()) {
                cmd.add("--upstream")
                cmd.add(cfg.upstreamProxy)
            }
            if (cfg.blockList.isNotBlank()) {
                cmd.add("--route-block")
                cmd.add(cfg.blockList)
            }
            val directEntries = ArrayList<String>()
            if (cfg.directList.isNotBlank()) directEntries.add(cfg.directList)
            if (cfg.directIr && !cfg.gameMode) directEntries.add("private,regexp:\\.ir$")
            if (directEntries.isNotEmpty()) {
                cmd.add("--route-direct")
                cmd.add(directEntries.joinToString(","))
            }
        }

        if (protocol == "psiphon_only") {
            val cmd = mutableListOf(
                aetherBin.absolutePath,
                "--bind", socksBind,
                "--psiphon-only"
            )
            appendPsiphonFlags(cmd)
            appendRoutingAndProxy(cmd)
            cmd.add("--log-level")
            cmd.add("debug")
            return cmd
        }

        val cmd = mutableListOf(aetherBin.absolutePath)
        if (protocol == "aether_psiphon") {
            cmd.add("--bind")
            cmd.add("127.0.0.1:${cfg.socksPort + 10}")
            cmd.add("--psiphon-bind")
            cmd.add(socksBind)
        } else {
            cmd.add("--bind")
            cmd.add(socksBind)
        }

        when (cfg.ipVersion) {
            "6" -> cmd.add("-6")
            "dual" -> cmd.add("--dual")
            else -> cmd.add("-4")
        }

        cmd.add(if (quickReconnect) "--quick-reconnect" else "--no-quick-reconnect")

        val isWgTransport = protocol in listOf("wg", "gool_classic")
        val useH2 = !isWgTransport && (forceH2 || cfg.transport == "h2" || protocol in listOf("masque_h2", "mim_h2", "psiphon_aether"))
        // On Cellular (MCI/Irancell), always pass --fragment so WARP API TLS calls also split SNI past DPI!
        if ((useH2 && (cfg.fragmentH2 || forceH2)) || isCellular) {
            cmd.add("--fragment")
            cmd.add("--fragment-size")
            cmd.add(if (isCellular) "4-10" else "8-16")
            cmd.add("--fragment-delay")
            cmd.add(if (isCellular) "3-10" else "1-4")
        }
        if (!apiAddressOverride.isNullOrBlank()) {
            cmd.add("--api-address")
            cmd.add(apiAddressOverride)
        }

        when (protocol) {
            "masque_h2" -> {
                cmd.add("--masque")
                cmd.add("--h2")
            }
            "mim" -> {
                cmd.add("--mim")
                if (useH2) cmd.add("--h2")
            }
            "mim_h2" -> {
                cmd.add("--mim")
                cmd.add("--h2")
            }
            "gool" -> {
                cmd.add("--gool")
                if (useH2) cmd.add("--h2")
            }
            "wg" -> {
                cmd.add("--wg")
                cmd.add("--keepalive")
                cmd.add("5")
            }
            "gool_classic" -> {
                cmd.add("--gool-classic")
                cmd.add("--keepalive")
                cmd.add("5")
            }
            "aether_psiphon" -> {
                cmd.add("--masque")
                if (useH2) cmd.add("--h2")
                cmd.add("--psiphon")
            }
            "psiphon_aether" -> {
                cmd.add("--masque")
                cmd.add("--h2")
                cmd.add("--psiphon-reverse")
            }
            else -> {
                cmd.add("--masque")
                if (useH2) cmd.add("--h2")
            }
        }

        if (protocol in listOf("aether_psiphon", "psiphon_aether")) {
            appendPsiphonFlags(cmd)
        }

        if (!sniOverride.isNullOrBlank() && !isWgTransport) {
            cmd.add("--masque-sni")
            cmd.add(sniOverride)
        }

        // Only force endpoint when the user explicitly entered a Custom Endpoint (never auto-override Aether's scanner!)
        if (cfg.customEndpoint.isNotBlank()) {
            when {
                protocol == "wg" -> {
                    cmd.add("--wg-peer")
                    cmd.add(cfg.customEndpoint)
                }
                protocol == "gool_classic" -> {
                    cmd.add("--wiw-outer")
                    cmd.add(cfg.customEndpoint)
                }
                useH2 -> {
                    cmd.add("--h2-peer")
                    cmd.add(cfg.customEndpoint)
                }
                else -> {
                    cmd.add("--peer")
                    cmd.add(cfg.customEndpoint)
                }
            }
        }

        if (cfg.stealthTls && !cfg.gameMode && !isWgTransport) {
            cmd.add("--enable-grease-sigalgs")
            cmd.add("--tls-cert-compression")
            cmd.add("brotli")
            cmd.add("--tls-alps")
            cmd.add("new")
            if (useEch) {
                cmd.add("--ech")
                cmd.add("auto")
            } else {
                cmd.add("--enable-ech-grease")
            }
        } else if (useEch && !cfg.gameMode && !isWgTransport) {
            cmd.add("--ech")
            cmd.add("auto")
        }

        appendRoutingAndProxy(cmd)

        if (cfg.avoidIrExit && protocol !in listOf("psiphon_only", "aether_psiphon")) {
            cmd.add("--exit-loc")
            cmd.add("!IR")
        }

        val effectiveScan = when (scan) {
            "turbo", "balanced", "thorough", "verified", "ironclad" -> scan
            else -> "turbo"
        }
        cmd.add("--scan")
        cmd.add(effectiveScan)

        // WireGuard / Gool-Classic only accept: off, light, balanced, aggressive (default = balanced, matching Aethon!)
        // MASQUE / Gool / MiM accept: off, light, firewall, gfw (default = firewall)
        val requestedNoize = noizeOverride ?: cfg.noize
        val effectiveNoize = if (isWgTransport) {
            when (requestedNoize) {
                "off", "light", "balanced", "aggressive" -> requestedNoize
                else -> "balanced"
            }
        } else {
            when (requestedNoize) {
                "off", "light", "firewall", "gfw" -> requestedNoize
                "balanced" -> "firewall"
                "aggressive" -> "gfw"
                else -> "firewall"
            }
        }
        cmd.add("--noize")
        cmd.add(effectiveNoize)

        if (cfg.extraArgs.isNotBlank()) {
            cmd.addAll(tokenizeArgs(cfg.extraArgs))
        }
        return cmd
    }

    private fun launchAetherProcess(cmd: List<String>, workDir: File, cfg: AetherLaunchConfig): Process {
        tunnelReadyFlag.set(false)
        lastErrorLine = ""
        emitLog("CMD: ${cmd.joinToString(" ")}")

        val psiphonBin = File(applicationInfo.nativeLibraryDir, "libpsiphon.so")
        val tmpDir = File(workDir, "tmp").apply { mkdirs() }
        val pb = ProcessBuilder(cmd).apply {
            directory(workDir)
            redirectErrorStream(true)
            val env = environment()
            env["AETHER_SOCKS"] = "${if (cfg.shareSocksLan) "0.0.0.0" else "127.0.0.1"}:${cfg.socksPort}"
            env["HOME"] = workDir.absolutePath
            env["TMPDIR"] = tmpDir.absolutePath
            // Do NOT override SSL_CERT_DIR so Aether & Psiphon auto-discover both
            // /system/etc/security/cacerts and /apex/com.android.conscrypt/cacerts (Android 14+)
            if (cfg.perfProfile in listOf("low", "medium", "high")) {
                env["AETHER_PERF_PROFILE"] = cfg.perfProfile
            }
            if (!cfg.rescanOnDrop) {
                env["AETHER_MASQUE_RECONNECT_SECS"] = "2"
                env["AETHER_WG_RECONNECT_SECS"] = "2"
            }
            val cleanDns = cfg.dns.split(",").map { it.trim() }.filter { it.isNotEmpty() }.joinToString(",")
            if (cleanDns.isNotEmpty()) {
                env["AETHER_DNS"] = cleanDns
            }
            if (psiphonBin.exists()) {
                env["AETHER_PSIPHON_BIN"] = psiphonBin.absolutePath
                env["AETHER_PSIPHON_READY_SECS"] = "110"
            }
        }
        val proc = pb.start()
        aetherProcess = proc
        try { proc.outputStream.close() } catch (_: Exception) {}

        Thread({
            try {
                var lastLogEmit = 0L
                proc.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        val trimmed = line.trim()
                        if (trimmed.isEmpty()) return@forEach

                        val lower = trimmed.lowercase()
                        if (lower.contains("[+] socks5") ||
                            lower.contains("[+] psiphon is ready") ||
                            lower.contains("[+] psiphon socks5 listening") ||
                            lower.contains("[+] gool ready") ||
                            lower.contains("socks5 server listening")
                        ) {
                            tunnelReadyFlag.set(true)
                        }
                        if (trimmed.startsWith("[-]") || lower.contains("error:") || lower.contains("failed")) {
                            lastErrorLine = trimmed
                        }

                        val isImportant = trimmed.startsWith("[+]") ||
                            trimmed.startsWith("[-]") ||
                            trimmed.startsWith("[*]") ||
                            lower.contains("error") ||
                            lower.contains("ready") ||
                            lower.contains("listening") ||
                            lower.contains("validated") ||
                            lower.contains("psiphon")
                        val now = System.currentTimeMillis()
                        if (isImportant || (isUiVisible && now - lastLogEmit > 250L)) {
                            lastLogEmit = now
                            emitLog("[Aether] $trimmed")
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }, "aether-log-reader").start()
        return proc
    }

    private fun acquireWakeLock(enable: Boolean) {
        releaseWakeLock()
        if (!enable) return
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VeloGuard::TunnelWakeLock").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    private fun terminateAetherProcess() {
        try {
            aetherProcess?.let { p ->
                p.destroy()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && p.isAlive) {
                    p.destroyForcibly()
                }
            }
        } catch (_: Exception) {}
        aetherProcess = null
    }

    private fun startAetherTunnel(cfg: AetherLaunchConfig) {
        stopping.set(false)
        workerExecutor.execute {
            cleanupCoreOnly()
            isServiceRunning = true
            activeSocksPort = cfg.socksPort
            activeProxyOnly = cfg.connectionMode == "proxy"
            acquireWakeLock(cfg.keepAwake)

            var activeProtocol = cfg.protocol
            emitState("connecting", if (cfg.gameMode) "شروع موتور گیم Full-UDP (پینگ پایین)..." else "شروع هسته (${cfg.protocol})...")

            try {
                val aetherBin = File(applicationInfo.nativeLibraryDir, "libaether.so")
                val psiphonBin = File(applicationInfo.nativeLibraryDir, "libpsiphon.so")
                if (!aetherBin.exists()) {
                    throw IllegalStateException("باینری libaether.so در این نسخه نصب نشده است.")
                }
                if (psiphonBin.exists() && !psiphonBin.canExecute()) {
                    try { psiphonBin.setExecutable(true, false) } catch (_: Exception) {}
                }
                if (!cfg.gameMode && cfg.protocol in listOf("psiphon_only", "aether_psiphon", "psiphon_aether") && !psiphonBin.exists()) {
                    throw IllegalStateException("هسته سایفون (libpsiphon.so) در این نسخه موجود نیست.")
                }

                val workDir = File(filesDir, "aether").apply { mkdirs() }
                val isCellular = CleanIpScanner.isCellularNetwork(this)
                val apiAddressOverride = resolveReachableWarpApiIp()

                data class Attempt(
                    val proto: String,
                    val scanMode: String,
                    val quick: Boolean,
                    val sni: String?,
                    val forceCdn: Boolean,
                    val forceH2: Boolean,
                    val useEch: Boolean,
                    val timeoutMs: Long,
                    val label: String,
                    val noizeOverride: String? = null,
                    val cdnSetsOverride: String? = null
                )

                val effectiveProtocol = if (cfg.gameMode && cfg.protocol in listOf("psiphon_only", "aether_psiphon", "psiphon_aether")) {
                    emitLog("[Game] Psiphon drops game UDP; switching to Full-UDP Gaming Engine (WG / MASQUE).")
                    "wg"
                } else {
                    cfg.protocol
                }

                val userH2 = cfg.transport == "h2"
                val attempts = when (effectiveProtocol) {
                    "wg" -> listOf(
                        Attempt("wg", cfg.scan, cfg.quickReconnect, null, false, false, false, 18_000L, "WARP WireGuard (${cfg.scan})"),
                        Attempt("wg", "balanced", false, null, false, false, false, 22_000L, "WARP WireGuard (اسکن جدید بدون کش)", "aggressive"),
                        Attempt("masque_h2", "balanced", false, null, false, true, false, 22_000L, "پشتیبان MASQUE H2 + Fragment (همراه اول / TCP 443)", "gfw"),
                        Attempt("masque_h2", "ironclad", false, "consumer-masque.cloudflareclient.com", false, true, false, 30_000L, "پشتیبان MASQUE H2 Ironclad", "gfw")
                    )
                    "smart_fast" -> if (isCellular) {
                        // On Iranian cellular (Hamrah-e-Aval / Irancell), TCP 443 fragmented MASQUE H2 is reliable and avoids UDP throttling!
                        listOf(
                            Attempt("masque_h2", "balanced", cfg.quickReconnect, null, false, true, false, 22_000L, "هوشمند دیتای موبایل (۱/۶): MASQUE H2 + Fragment (همراه اول / ایرانسل)", "firewall"),
                            Attempt("masque_h2", "ironclad", false, null, false, true, false, 30_000L, "هوشمند دیتای موبایل (۲/۶): MASQUE H2 Ironclad (تست دیتای واقعی)", "gfw"),
                            Attempt("masque_h2", "balanced", false, "consumer-masque.cloudflareclient.com", false, true, false, 24_000L, "هوشمند دیتای موبایل (۳/۶): MASQUE H2 (SNI جایگزین)", "gfw"),
                            Attempt("masque", "balanced", false, null, false, false, cfg.echAuto, 16_000L, "هوشمند دیتای موبایل (۴/۶): MASQUE H3", "gfw"),
                            Attempt("wg", "balanced", false, null, false, false, false, 16_000L, "هوشمند دیتای موبایل (۵/۶): WARP WireGuard", "aggressive"),
                            Attempt("aether_psiphon", "turbo", false, null, true, true, false, 75_000L, "هوشمند دیتای موبایل (۶/۶): MASQUE H2 → سایفون CDN", "gfw", "cloudflare,fastly,cloudfront,curated-fronting")
                        )
                    } else {
                        listOf(
                            Attempt("masque", "turbo", cfg.quickReconnect, null, false, false, cfg.echAuto, 14_000L, "سریع Wi-Fi (۱/۵): MASQUE H3"),
                            Attempt("wg", "turbo", cfg.quickReconnect, null, false, false, false, 15_000L, "سریع Wi-Fi (۲/۵): WARP WireGuard Turbo"),
                            Attempt("masque_h2", "balanced", false, null, false, true, false, 22_000L, "سریع Wi-Fi (۳/۵): MASQUE H2 + Fragment", "firewall"),
                            Attempt("masque_h2", "ironclad", false, "consumer-masque.cloudflareclient.com", false, true, false, 28_000L, "سریع Wi-Fi (۴/۵): MASQUE H2 Ironclad", "gfw"),
                            Attempt("aether_psiphon", "turbo", false, null, true, true, false, 70_000L, "سریع Wi-Fi (۵/۵): MASQUE H2 → سایفون CDN", "gfw", "cloudflare,fastly,cloudfront,curated-fronting")
                        )
                    }
                    "masque" -> listOf(
                        Attempt("masque", cfg.scan, cfg.quickReconnect, null, false, userH2, cfg.echAuto, if (userH2) 22_000L else (if (isCellular) 14_000L else 18_000L), if (userH2) "MASQUE H2" else "MASQUE H3"),
                        Attempt("masque_h2", "balanced", false, null, false, true, false, 22_000L, "MASQUE H2 + Fragment (پشتیبان TCP 443)", "gfw"),
                        Attempt("masque_h2", "ironclad", false, "consumer-masque.cloudflareclient.com", false, true, false, 30_000L, "MASQUE H2 Ironclad (SNI جایگزین)", "gfw"),
                        Attempt("wg", "balanced", true, null, false, false, false, 18_000L, "WARP WireGuard (جایگزین سریع)")
                    )
                    "masque_h2" -> listOf(
                        Attempt("masque_h2", if (cfg.scan == "turbo") "balanced" else cfg.scan, cfg.quickReconnect, null, false, true, cfg.echAuto, 22_000L, "MASQUE H2 + Fragment", "firewall"),
                        Attempt("masque_h2", "ironclad", false, null, false, true, false, 30_000L, "MASQUE H2 Ironclad (تست دیتای واقعی)", "gfw"),
                        Attempt("masque_h2", "balanced", false, "consumer-masque.cloudflareclient.com", false, true, false, 24_000L, "MASQUE H2 (SNI جایگزین کلودفلر)", "gfw")
                    )
                    "mim" -> listOf(
                        Attempt("mim", if (cfg.scan == "turbo") "balanced" else cfg.scan, cfg.quickReconnect, null, false, userH2, cfg.echAuto, 28_000L, "MASQUE-in-MASQUE"),
                        Attempt("mim_h2", "balanced", false, null, false, true, false, 34_000L, "MASQUE-in-MASQUE H2", "gfw"),
                        Attempt("gool", "balanced", false, null, false, true, false, 34_000L, "Gool H2 (جایگزین)", "gfw")
                    )
                    "gool" -> listOf(
                        Attempt("gool", if (cfg.scan == "turbo") "balanced" else cfg.scan, cfg.quickReconnect, null, false, userH2, cfg.echAuto, 28_000L, "WARP-in-MASQUE (Gool)"),
                        Attempt("gool", "balanced", false, null, false, true, false, 34_000L, "Gool H2 (TCP 443)", "gfw"),
                        Attempt("gool_classic", "balanced", false, null, false, false, false, 32_000L, "WARP-in-WARP (Gool Classic)")
                    )
                    "gool_classic" -> listOf(
                        Attempt("gool_classic", cfg.scan, cfg.quickReconnect, null, false, false, false, 28_000L, "WARP-in-WARP (Gool Classic)"),
                        Attempt("wg", "turbo", true, null, false, false, false, 18_000L, "WARP WireGuard (جایگزین سریع)")
                    )
                    "psiphon_only" -> listOf(
                        // Use fast CDN fronting sets first (DisableTactics=true avoids Android BPF 'operation not permitted'!)
                        Attempt("psiphon_only", cfg.scan, true, null, true, false, false, 115_000L, "سایفون CDN سریع (Cloudflare/Fastly/CloudFront)", null, "cloudflare,fastly,cloudfront,curated-fronting"),
                        Attempt("psiphon_only", cfg.scan, false, null, true, false, false, 100_000L, "سایفون CDN کامل (همه لبه‌ها)"),
                        Attempt("aether_psiphon", "balanced", false, null, true, true, false, 90_000L, "زنجیره MASQUE H2 → سایفون", "gfw", "cloudflare,fastly,cloudfront,curated-fronting")
                    )
                    "aether_psiphon" -> listOf(
                        Attempt("aether_psiphon", cfg.scan, cfg.quickReconnect, null, true, userH2 || isCellular, cfg.echAuto, 90_000L, "زنجیره Aether → سایفون CDN", "gfw", "cloudflare,fastly,cloudfront,curated-fronting"),
                        Attempt("psiphon_only", cfg.scan, false, null, true, false, false, 110_000L, "سایفون CDN (Fallback)")
                    )
                    "psiphon_aether" -> listOf(
                        Attempt("psiphon_aether", cfg.scan, cfg.quickReconnect, null, true, true, false, 90_000L, "زنجیره سایفون → Aether MASQUE H2", "gfw", "cloudflare,fastly,cloudfront,curated-fronting"),
                        Attempt("psiphon_only", cfg.scan, false, null, true, false, false, 110_000L, "سایفون CDN (Fallback)")
                    )
                    "rescue" -> listOf(
                        Attempt("masque_h2", "balanced", false, null, false, true, false, 22_000L, "نجات (۱/۴): MASQUE H2 + Fragment (همراه اول / ایرانسل)", "gfw"),
                        Attempt("masque_h2", "ironclad", false, "consumer-masque.cloudflareclient.com", false, true, false, 30_000L, "نجات (۲/۴): MASQUE H2 Ironclad", "gfw"),
                        Attempt("wg", "balanced", false, null, false, false, false, 18_000L, "نجات (۳/۴): WARP WireGuard", "aggressive"),
                        Attempt("psiphon_only", "balanced", false, null, true, false, false, 110_000L, "نجات (۴/۴): سایفون CDN Fronting", null, "cloudflare,fastly,cloudfront,curated-fronting")
                    )
                    else -> listOf(
                        Attempt(effectiveProtocol, cfg.scan, cfg.quickReconnect, null, false, userH2, cfg.echAuto, 24_000L, effectiveProtocol.uppercase())
                    )
                }

                var connectedReady = false
                for ((idx, att) in attempts.withIndex()) {
                    if (stopping.get()) return@execute
                    activeProtocol = att.proto
                    if (idx > 0) {
                        terminateAetherProcess()
                        emitState("connecting", "تلاش مجدد: ${att.label}...")
                    }
                    val cmd = buildAetherCommand(
                        aetherBin, psiphonBin, workDir, cfg,
                        att.proto, att.scanMode, att.quick, att.sni,
                        att.forceCdn, att.forceH2, att.useEch,
                        att.noizeOverride, att.cdnSetsOverride, apiAddressOverride, isCellular
                    )
                    val proc = launchAetherProcess(cmd, workDir, cfg)
                    if (waitForSocksReady(proc, cfg.socksPort, timeoutMs = att.timeoutMs)) {
                        connectedReady = true
                        break
                    }
                    terminateAetherProcess()
                }

                if (!connectedReady || stopping.get()) {
                    if (!stopping.get()) {
                        val detail = if (lastErrorLine.isNotBlank()) " ($lastErrorLine)" else ""
                        throw IllegalStateException("تونل پاسخ نداد$detail؛ پروتکل دیگر یا حالت نجات را امتحان کنید.")
                    }
                    return@execute
                }

                if (cfg.connectionMode == "proxy") {
                    val bindHost = if (cfg.shareSocksLan) "0.0.0.0" else "127.0.0.1"
                    val httpText = if (cfg.httpProxyEnabled) " · HTTP $bindHost:${cfg.socksPort + 1}" else ""
                    updateNotification("Proxy Only · SOCKS5 $bindHost:${cfg.socksPort}$httpText")
                    emitState("connected", "پراکسی محلی آماده است ✅ (SOCKS5 $bindHost:${cfg.socksPort}$httpText)")
                    startStatsPolling()
                    return@execute
                }

                val useMapDns = activeProtocol == "psiphon_only"
                val builder = Builder()
                    .setSession(if (cfg.gameMode) "VeloGuard Gaming UDP" else "VeloGuard (${activeProtocol.uppercase()})")
                    .setBlocking(false)
                    .setMtu(cfg.mtu)
                    .addAddress("198.18.0.1", if (useMapDns) 32 else 24)
                    .addRoute("0.0.0.0", 0)

                if (useMapDns) {
                    builder.addDnsServer("198.18.0.2")
                } else {
                    val dnsList = cfg.dns.split(",")
                        .map { it.trim() }
                        .filter { it.matches(Regex("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) }
                    if (dnsList.isNotEmpty()) {
                        dnsList.forEach { builder.addDnsServer(it) }
                    } else {
                        builder.addDnsServer("1.1.1.1")
                        builder.addDnsServer("1.0.0.1")
                    }
                }

                try { builder.addDisallowedApplication(packageName) } catch (_: Exception) {}

                cfg.excludedApps.split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() && it != packageName }
                    .forEach { pkg ->
                        try { builder.addDisallowedApplication(pkg) } catch (_: Exception) {}
                    }

                val pfd = builder.establish()
                    ?: throw IllegalStateException("ایجاد رابط TUN توسط سیستم‌عامل رد شد.")
                tunInterface = pfd

                val udpRecvBuf = if (cfg.gameMode) 524288 else 131072
                val udpTimeoutMs = if (cfg.gameMode) 180000 else 60000
                val tcpBufBytes = (cfg.tcpBufferKb * 1024).coerceIn(16384, 4_194_304)
                val mapDnsBlock = if (useMapDns) {
                    """
                    mapdns:
                      address: 198.18.0.2
                      port: 53
                      network: 100.64.0.0
                      netmask: 255.192.0.0
                      cache-size: 10000
                    """.trimIndent() + "\n"
                } else ""
                val yamlFile = File(filesDir, "tproxy.yml")
                yamlFile.writeText(
                    """
                    tunnel:
                      name: tun0
                      mtu: ${cfg.mtu}
                      multi-queue: false
                      ipv4: 198.18.0.1
                      icmp: 'reply'
                    socks5:
                      port: ${cfg.socksPort}
                      address: 127.0.0.1
                      udp: 'udp'
                    ${mapDnsBlock}misc:
                      task-stack-size: 65536
                      tcp-buffer-size: $tcpBufBytes
                      udp-recv-buffer-size: $udpRecvBuf
                      connect-timeout: 10000
                      tcp-read-write-timeout: 300000
                      udp-read-write-timeout: $udpTimeoutMs
                      log-level: warn
                    """.trimIndent()
                )

                val started = TProxyService.TProxyStartService(yamlFile.absolutePath, pfd.fd)
                if (!started) {
                    throw IllegalStateException("راه‌اندازی موتور hev-socks5-tunnel ناموفق بود.")
                }

                updateNotification(if (cfg.gameMode) "متصل · Gaming Full-UDP (${activeProtocol.uppercase()})" else "متصل · ${activeProtocol.uppercase()}")
                val extraNote = if (cfg.gameMode) {
                    "حالت گیم Full-UDP (${activeProtocol.uppercase()}) فعال شد 🎮✅"
                } else if (cfg.protocol != activeProtocol) {
                    "تونل برقرار شد ✅ (سوییچ خودکار به ${activeProtocol.uppercase()})"
                } else {
                    "تونل (${activeProtocol.uppercase()}) برقرار شد ✅"
                }
                emitState("connected", extraNote)
                startStatsPolling()

            } catch (e: Exception) {
                if (!stopping.get()) {
                    emitLog("ERROR: ${e.message}")
                    stopAetherTunnel("خطا در اتصال: ${e.message ?: "نامشخص"}")
                }
            }
        }
    }

    private fun waitForSocksReady(proc: Process, socksPort: Int, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline && !stopping.get()) {
            if (!proc.isAlive) return false
            val remaining = deadline - System.currentTimeMillis()
            if (remaining <= 0) break

            val handshakeOk = if (tunnelReadyFlag.get()) {
                probeSocks5Handshake(socksPort, readTimeoutMs = 1500)
            } else {
                val waitSlice = remaining.coerceAtMost(4000L).toInt().coerceAtLeast(800)
                probeSocks5Handshake(socksPort, readTimeoutMs = waitSlice)
            }

            if (handshakeOk) {
                emitLog("[Verify] SOCKS5 listening; checking real TLS 443 download through tunnel...")
                if (verifySocks5DataFlow(socksPort, host = "www.cloudflare.com", port = 443, path = "/cdn-cgi/trace", useTls = true, minBytes = 100) ||
                    verifySocks5DataFlow(socksPort, host = "cp.cloudflare.com", port = 80, path = "/generate_204", useTls = false, minBytes = 12)
                ) {
                    emitLog("[Verify] Real TLS/HTTP download OK! Opening VPN tunnel.")
                    return true
                }
                Thread.sleep(700)
                if (!proc.isAlive) return false
                if (verifySocks5DataFlow(socksPort, host = "www.gstatic.com", port = 443, path = "/generate_204", useTls = true, minBytes = 12)) {
                    emitLog("[Verify] Real TLS download OK on retry! Opening VPN tunnel.")
                    return true
                }
                emitLog("[Verify] Tunnel failed real TLS download check (throttled or stalled); switching...")
                return false
            }

            if (!proc.isAlive) return false
            try { Thread.sleep(250) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    private fun verifySocks5DataFlow(
        socksPort: Int,
        host: String = "www.cloudflare.com",
        port: Int = 443,
        path: String = "/cdn-cgi/trace",
        useTls: Boolean = true,
        minBytes: Int = 80
    ): Boolean {
        return try {
            Socket().use { s ->
                s.soTimeout = 5500
                s.connect(InetSocketAddress("127.0.0.1", socksPort), 2000)
                val rawOut = s.getOutputStream()
                val rawIn = s.getInputStream()
                // 1. SOCKS5 greeting
                rawOut.write(byteArrayOf(0x05, 0x01, 0x00))
                rawOut.flush()
                if (rawIn.read() != 0x05 || rawIn.read() != 0x00) return false

                // 2. SOCKS5 CONNECT host:port (ATYP_DOMAIN = 0x03)
                val hostBytes = host.toByteArray(Charsets.UTF_8)
                val req = ByteArray(7 + hostBytes.size)
                req[0] = 0x05
                req[1] = 0x01
                req[2] = 0x00
                req[3] = 0x03
                req[4] = hostBytes.size.toByte()
                System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
                req[5 + hostBytes.size] = ((port ushr 8) and 0xFF).toByte()
                req[6 + hostBytes.size] = (port and 0xFF).toByte()
                rawOut.write(req)
                rawOut.flush()

                val rep = ByteArray(4)
                var got = 0
                while (got < 4) {
                    val r = rawIn.read(rep, got, 4 - got)
                    if (r <= 0) return false
                    got += r
                }
                if (rep[0].toInt() != 0x05 || rep[1].toInt() != 0x00) return false
                val skipLen = when (rep[3].toInt()) {
                    0x01 -> 4 + 2
                    0x04 -> 16 + 2
                    0x03 -> {
                        val l = rawIn.read()
                        if (l < 0) return false
                        l + 2
                    }
                    else -> return false
                }
                val dump = ByteArray(skipLen)
                var dGot = 0
                while (dGot < skipLen) {
                    val r = rawIn.read(dump, dGot, skipLen - dGot)
                    if (r <= 0) return false
                    dGot += r
                }

                // 3. Wrap in real TLS if requested and verify real HTTP response + payload bytes arrive
                if (useTls) {
                    val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
                    val ssl = factory.createSocket(s, host, port, true) as SSLSocket
                    ssl.use { tlsSock ->
                        tlsSock.soTimeout = 5500
                        val params = tlsSock.sslParameters
                        params.serverNames = listOf(SNIHostName(host))
                        tlsSock.sslParameters = params
                        tlsSock.startHandshake()
                        val tOut = tlsSock.getOutputStream()
                        val tIn = tlsSock.getInputStream()
                        tOut.write("GET $path HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n".toByteArray(Charsets.US_ASCII))
                        tOut.flush()
                        val buf = ByteArray(1024)
                        var total = 0
                        var firstChunk = ""
                        while (total < minBytes) {
                            val n = tIn.read(buf)
                            if (n <= 0) break
                            if (firstChunk.isEmpty()) firstChunk = String(buf, 0, n.coerceAtMost(32), Charsets.US_ASCII)
                            total += n
                        }
                        firstChunk.startsWith("HTTP/") && total >= minBytes
                    }
                } else {
                    rawOut.write("GET $path HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n".toByteArray(Charsets.US_ASCII))
                    rawOut.flush()
                    val buf = ByteArray(256)
                    val n = rawIn.read(buf)
                    n >= minBytes && String(buf, 0, n, Charsets.US_ASCII).startsWith("HTTP/")
                }
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun probeSocks5Handshake(socksPort: Int, readTimeoutMs: Int): Boolean {
        return try {
            Socket().use { s ->
                s.soTimeout = readTimeoutMs
                s.connect(InetSocketAddress("127.0.0.1", socksPort), 1000)
                val out = s.getOutputStream()
                out.write(byteArrayOf(0x05, 0x01, 0x00))
                out.flush()
                val inp = s.getInputStream()
                val b0 = inp.read()
                val b1 = inp.read()
                b0 == 0x05 && b1 == 0x00
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun startStatsPolling() {
        stopStatsPolling()
        lastSentRx = -1L
        lastSentTx = -1L
        statsTask = statsScheduler.scheduleAtFixedRate({
            try {
                if (!isServiceRunning || stopping.get()) return@scheduleAtFixedRate
                if (aetherProcess?.isAlive == false) {
                    stopAetherTunnel("پروسه هسته متوقف شد.")
                    return@scheduleAtFixedRate
                }
                if (!isUiVisible || activeProxyOnly) return@scheduleAtFixedRate
                val stats = TProxyService.TProxyGetStats()
                if (stats.size >= 4) {
                    val txBytes = stats[1]
                    val rxBytes = stats[3]
                    if (rxBytes != lastSentRx || txBytes != lastSentTx) {
                        lastSentRx = rxBytes
                        lastSentTx = txBytes
                        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
                            putExtra(EVENT_TYPE, "stats")
                            putExtra(EVENT_RX, rxBytes)
                            putExtra(EVENT_TX, txBytes)
                        })
                    }
                }
            } catch (_: Exception) {
            }
        }, 800, 2000, TimeUnit.MILLISECONDS)
    }

    private fun stopStatsPolling() {
        statsTask?.cancel(false)
        statsTask = null
    }

    private fun cleanupCoreOnly() {
        stopStatsPolling()
        releaseWakeLock()
        try {
            if (TProxyService.TProxyIsRunning()) {
                TProxyService.TProxyStopService()
            }
        } catch (_: Exception) {
        }
        try { tunInterface?.close() } catch (_: Exception) {}
        tunInterface = null
        terminateAetherProcess()
    }

    private fun stopAetherTunnel(reason: String) {
        if (stopping.getAndSet(true)) return
        workerExecutor.execute {
            cleanupCoreOnly()
            isServiceRunning = false
            emitState("disconnected", reason)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun emitState(state: String, msg: String?) {
        currentState = state
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "state")
            putExtra(EVENT_STATE, state)
            if (msg != null) putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun emitLog(msg: String) {
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "log")
            putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                CHANNEL_ID,
                "VeloGuard Aether VPN",
                NotificationManager.IMPORTANCE_LOW
            )
            nm?.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pendingOpen = PendingIntent.getActivity(this, 0, openIntent, flags)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("VeloGuard")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pendingOpen)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.notify(NOTIF_ID, buildNotification(text))
        } catch (_: Exception) {
        }
    }

    override fun onRevoke() {
        stopAetherTunnel("مجوز VPN لغو شد.")
        super.onRevoke()
    }

    override fun onDestroy() {
        stopping.set(true)
        cleanupCoreOnly()
        isServiceRunning = false
        currentState = "disconnected"
        workerExecutor.shutdownNow()
        statsScheduler.shutdownNow()
        super.onDestroy()
    }
}
