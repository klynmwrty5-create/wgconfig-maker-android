package com.tunweb.wireguard

import com.wireguard.android.backend.Tunnel

class WgTunnel(
    private var tunnelName: String = "TunWebTunnel",
    private val onStateChangeCallback: (Tunnel.State) -> Unit
) : Tunnel {

    fun setName(name: String) {
        val clean = name.replace(Regex("[^a-zA-Z0-9_=+.-]"), "_").take(15)
        tunnelName = clean.ifBlank { "TunWebTunnel" }
    }

    override fun getName(): String = tunnelName

    override fun onStateChange(newState: Tunnel.State) {
        onStateChangeCallback(newState)
    }
}
