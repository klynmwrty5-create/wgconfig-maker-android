package com.tunweb.wireguard

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import de.blinkt.openvpn.VpnProfile
import de.blinkt.openvpn.core.ConfigParser
import de.blinkt.openvpn.core.ConnectionStatus
import de.blinkt.openvpn.core.IOpenVPNServiceInternal
import de.blinkt.openvpn.core.LogItem
import de.blinkt.openvpn.core.OpenVPNService
import de.blinkt.openvpn.core.ProfileManager
import de.blinkt.openvpn.core.VPNLaunchHelper
import de.blinkt.openvpn.core.VpnStatus
import java.io.File
import java.io.StringReader
import java.util.concurrent.atomic.AtomicBoolean

object OpenVpnBackend : VpnStatus.StateListener, VpnStatus.ByteCountListener, VpnStatus.LogListener {

    interface Listener {
        fun onOpenVpnState(state: String, message: String?)
        fun onOpenVpnStats(rxBytes: Long, txBytes: Long)
        fun onOpenVpnLog(line: String)
    }

    private lateinit var appContext: Context
    private val initialized = AtomicBoolean(false)

    @Volatile
    private var listener: Listener? = null

    @Volatile
    var isRunning: Boolean = false
        private set

    @Volatile
    var currentState: String = "disconnected"
        private set

    @Volatile
    private var lastRx: Long = -1L

    @Volatile
    private var lastTx: Long = -1L

    @Volatile
    private var lastLogEmitMs: Long = 0L

    @Volatile
    private var lastErrorMsg: String = ""

    fun init(context: Context, cb: Listener) {
        appContext = context.applicationContext
        listener = cb
        if (initialized.compareAndSet(false, true)) {
            VpnStatus.addStateListener(this)
            VpnStatus.addByteCountListener(this)
            VpnStatus.addLogListener(this)
        }
    }

    fun isAvailable(context: Context): Boolean {
        val hasExec = File(context.applicationInfo.nativeLibraryDir, "libovpnexec.so").exists()
        val hasClass = try {
            Class.forName("de.blinkt.openvpn.core.VPNLaunchHelper")
            true
        } catch (_: Throwable) {
            false
        }
        return hasExec || hasClass
    }

    private fun needsKeystoreCertificate(profile: VpnProfile): Boolean {
        return when (profile.mAuthenticationType) {
            VpnProfile.TYPE_KEYSTORE,
            VpnProfile.TYPE_USERPASS_KEYSTORE,
            VpnProfile.TYPE_EXTERNAL_APP -> profile.mAlias == null
            else -> false
        }
    }

    private fun normalizeOvpnForV26(raw: String): String {
        val sb = StringBuilder(raw.length + 128)
        val lower = raw.lowercase()
        // Strip Windows CR and legacy options that break OpenVPN 2.6 strict parsing
        for (line in raw.replace("\r\n", "\n").lines()) {
            val trim = line.trim()
            if (trim.startsWith("block-outside-dns", ignoreCase = true)) continue
            sb.append(line).append('\n')
        }
        // VPNGate & older servers use AES-128-CBC without NCP/data-ciphers; OpenVPN 2.6 rejects them unless included!
        if (!Regex("(?im)^\\s*data-ciphers\\b").containsMatchIn(lower)) {
            sb.append("data-ciphers AES-256-GCM:AES-128-GCM:CHACHA20-POLY1305:AES-128-CBC\n")
        }
        if (!Regex("(?im)^\\s*connect-retry-max\\b").containsMatchIn(lower)) {
            sb.append("connect-retry-max 1\n")
        }
        if (!Regex("(?im)^\\s*connect-timeout\\b").containsMatchIn(lower)) {
            sb.append("connect-timeout 8\n")
        }
        return sb.toString()
    }

    fun connect(
        ovpnText: String,
        username: String,
        password: String,
        profileName: String,
        dnsCsv: String,
        excludedCsv: String
    ) {
        val normalizedOvpn = normalizeOvpnForV26(ovpnText)
        val profile: VpnProfile = ConfigParser().run {
            parseConfig(StringReader(normalizedOvpn))
            convertProfile()
        }

        val hasInlineCert = !profile.mClientCertFilename.isNullOrBlank() || !profile.mClientKeyFilename.isNullOrBlank()
        if (username.isNotBlank() || password.isNotBlank()) {
            profile.mUsername = username.trim()
            profile.mPassword = password
            profile.mAuthenticationType = if (hasInlineCert) {
                VpnProfile.TYPE_USERPASS_CERTIFICATES
            } else {
                VpnProfile.TYPE_USERPASS
            }
        }

        require(!needsKeystoreCertificate(profile)) {
            "این فایل .ovpn فاقد کلید/گواهی داخلی یا نام کاربری و رمز است."
        }

        profile.mName = profileName.ifBlank { "VeloGuard OpenVPN" }
        profile.mPersistTun = true
        profile.mUsePull = true
        profile.mAllowLocalLAN = true
        profile.mBlockUnusedAddressFamilies = true

        val dnsList = dnsCsv.split(",")
            .map { it.trim() }
            .filter { it.matches(Regex("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) }
        if (dnsList.isNotEmpty()) {
            profile.mOverrideDNS = true
            profile.mDNS1 = dnsList[0]
            profile.mDNS2 = dnsList.getOrElse(1) { dnsList[0] }
        }

        val excluded = excludedCsv.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() && it != appContext.packageName }
        if (excluded.isNotEmpty()) {
            profile.mAllowedAppsVpnAreDisallowed = true
            profile.mAllowedAppsVpn.addAll(excluded)
        }

        ProfileManager.setTemporaryProfile(appContext, profile)
        lastRx = -1L
        lastTx = -1L
        lastErrorMsg = ""
        isRunning = true
        currentState = "connecting"
        listener?.onOpenVpnState("connecting", "در حال اتصال OpenVPN (${profile.mName})...")
        VPNLaunchHelper.startOpenVpn(profile, appContext, "VeloGuard", false)
    }

    fun disconnect() {
        if (!isRunning && currentState == "disconnected") return
        isRunning = false
        currentState = "disconnected"

        val intent = Intent(appContext, OpenVPNService::class.java).apply {
            action = OpenVPNService.START_SERVICE
        }
        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val service = IOpenVPNServiceInternal.Stub.asInterface(binder)
                try {
                    service?.stopVPN(false)
                } catch (_: Exception) {
                } finally {
                    try { appContext.unbindService(this) } catch (_: Exception) {}
                }
            }

            override fun onServiceDisconnected(name: ComponentName?) {}
        }

        val bound = try {
            appContext.bindService(intent, conn, 0)
        } catch (_: Exception) {
            false
        }
        if (!bound) {
            try { appContext.unbindService(conn) } catch (_: Exception) {}
            listener?.onOpenVpnState("disconnected", "اتصال OpenVPN قطع شد.")
        }
    }

    override fun updateState(
        state: String?,
        logmessage: String?,
        localizedResId: Int,
        level: ConnectionStatus?,
        intent: Intent?
    ) {
        val mapped = when (level) {
            ConnectionStatus.LEVEL_CONNECTED -> "connected"
            ConnectionStatus.LEVEL_START,
            ConnectionStatus.LEVEL_CONNECTING_SERVER_REPLIED,
            ConnectionStatus.LEVEL_CONNECTING_NO_SERVER_REPLY_YET,
            ConnectionStatus.LEVEL_WAITING_FOR_USER_INPUT,
            ConnectionStatus.LEVEL_NONETWORK -> "connecting"
            ConnectionStatus.LEVEL_NOTCONNECTED,
            ConnectionStatus.LEVEL_AUTH_FAILED -> "disconnected"
            else -> if (isRunning) "connecting" else "disconnected"
        }

        if (mapped == "connected") {
            isRunning = true
            currentState = "connected"
            listener?.onOpenVpnState("connected", "تونل OpenVPN برقرار شد ✅")
        } else if (mapped == "disconnected") {
            val wasActive = isRunning || currentState != "disconnected"
            isRunning = false
            currentState = "disconnected"
            if (wasActive) {
                val msg = when {
                    level == ConnectionStatus.LEVEL_AUTH_FAILED ->
                        "خطای نام کاربری یا رمز OpenVPN (Auth Failed)"
                    lastErrorMsg.isNotBlank() ->
                        "اتصال OpenVPN قطع شد: $lastErrorMsg"
                    else ->
                        "اتصال OpenVPN قطع شد."
                }
                listener?.onOpenVpnState("disconnected", msg)
            }
        } else {
            isRunning = true
            currentState = "connecting"
            val detail = logmessage?.takeIf { it.isNotBlank() } ?: state
            if (!detail.isNullOrBlank()) {
                listener?.onOpenVpnLog("[OpenVPN] $detail")
            }
        }
    }

    override fun setConnectedVPN(uuid: String?) {}

    override fun updateByteCount(inBytes: Long, outBytes: Long, diffIn: Long, diffOut: Long) {
        if (!isRunning) return
        if (inBytes != lastRx || outBytes != lastTx) {
            lastRx = inBytes
            lastTx = outBytes
            listener?.onOpenVpnStats(inBytes, outBytes)
        }
    }

    override fun newLog(logItem: LogItem?) {
        if (logItem == null) return
        val now = System.currentTimeMillis()
        val msg = try {
            if (::appContext.isInitialized) logItem.getString(appContext) else logItem.toString()
        } catch (_: Exception) {
            logItem.toString()
        } ?: return
        val lower = msg.lowercase()
        val important = lower.contains("error") || lower.contains("fail") ||
            lower.contains("auth") || lower.contains("connected") ||
            lower.contains("tls") || lower.contains("peer") ||
            lower.contains("reset") || lower.contains("cipher") ||
            lower.contains("timeout") || lower.contains("sigterm")
        if (lower.contains("error") || lower.contains("fail") || lower.contains("reset") ||
            lower.contains("tls") || lower.contains("cipher") || lower.contains("timeout")
        ) {
            lastErrorMsg = msg.take(120)
        }
        if (important || now - lastLogEmitMs > 300L) {
            lastLogEmitMs = now
            listener?.onOpenVpnLog("[OpenVPN] $msg")
        }
    }
}
