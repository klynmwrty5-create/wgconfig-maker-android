package com.tunweb.wireguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import hev.htproxy.TProxyService
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class AetherVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.tunweb.wireguard.AETHER_START"
        const val ACTION_STOP = "com.tunweb.wireguard.AETHER_STOP"
        const val ACTION_EVENT = "com.tunweb.wireguard.AETHER_EVENT"

        const val EXTRA_PROTOCOL = "protocol"
        const val EXTRA_SCAN = "scan"
        const val EXTRA_NOIZE = "noize"
        const val EXTRA_MTU = "mtu"
        const val EXTRA_FRAGMENT = "fragment"
        const val EXTRA_DNS = "dns"
        const val EXTRA_EXCLUDED_APPS = "excluded_apps"
        const val EXTRA_PSIPHON_REGION = "psiphon_region"
        const val EXTRA_PSIPHON_CDN = "psiphon_cdn"
        const val EXTRA_STEALTH_TLS = "stealth_tls"
        const val EXTRA_ECH_AUTO = "ech_auto"
        const val EXTRA_DIRECT_IR = "direct_ir"
        const val EXTRA_AVOID_IR_EXIT = "avoid_ir_exit"

        const val EVENT_TYPE = "type"
        const val EVENT_STATE = "state"
        const val EVENT_MESSAGE = "message"
        const val EVENT_RX = "rx"
        const val EVENT_TX = "tx"

        private const val CHANNEL_ID = "novaguard_aether_vpn"
        private const val NOTIF_ID = 8018
        private const val SOCKS_PORT = 1819

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        @Volatile
        var currentState: String = "disconnected"
            private set
    }

    private val workerExecutor = Executors.newSingleThreadExecutor()
    private val statsScheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var statsTask: ScheduledFuture<*>? = null

    private var aetherProcess: Process? = null
    private var tunInterface: ParcelFileDescriptor? = null
    private val stopping = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAetherTunnel("اتصال Aether قطع شد.")
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val protocol = intent.getStringExtra(EXTRA_PROTOCOL) ?: "masque"
                val scan = intent.getStringExtra(EXTRA_SCAN) ?: "turbo"
                val noize = intent.getStringExtra(EXTRA_NOIZE) ?: "firewall"
                val mtu = intent.getIntExtra(EXTRA_MTU, 1280).coerceIn(1200, 1500)
                val fragment = intent.getBooleanExtra(EXTRA_FRAGMENT, false)
                val dns = intent.getStringExtra(EXTRA_DNS) ?: "1.1.1.1, 8.8.8.8"
                val excluded = intent.getStringExtra(EXTRA_EXCLUDED_APPS) ?: ""
                val psiphonRegion = intent.getStringExtra(EXTRA_PSIPHON_REGION) ?: ""
                val psiphonCdn = intent.getBooleanExtra(EXTRA_PSIPHON_CDN, false)
                val stealthTls = intent.getBooleanExtra(EXTRA_STEALTH_TLS, true)
                val echAuto = intent.getBooleanExtra(EXTRA_ECH_AUTO, false)
                val directIr = intent.getBooleanExtra(EXTRA_DIRECT_IR, true)
                val avoidIrExit = intent.getBooleanExtra(EXTRA_AVOID_IR_EXIT, false)

                createNotificationChannel()
                val notif = buildNotification("NovaGuard (${protocol.uppercase()}) در حال اتصال...")
                try {
                    if (Build.VERSION.SDK_INT >= 34) {
                        startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                    } else {
                        startForeground(NOTIF_ID, notif)
                    }
                } catch (_: Exception) {
                }
                startAetherTunnel(protocol, scan, noize, mtu, fragment, dns, excluded, psiphonRegion, psiphonCdn, stealthTls, echAuto, directIr, avoidIrExit)
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun buildAetherCommand(
        aetherBin: File,
        psiphonBin: File,
        workDir: File,
        protocol: String,
        scan: String,
        noize: String,
        quickReconnect: Boolean,
        sniOverride: String? = null,
        psiphonRegion: String = "",
        psiphonCdn: Boolean = false,
        forceH2: Boolean = false,
        stealthTls: Boolean = true,
        echAuto: Boolean = false,
        directIr: Boolean = true,
        avoidIrExit: Boolean = false
    ): List<String> {
        val psiphonDataDir = File(workDir, "psiphon").apply { mkdirs() }

        fun appendPsiphonFlags(cmd: MutableList<String>) {
            if (psiphonBin.exists()) {
                cmd.add("--psiphon-bin")
                cmd.add(psiphonBin.absolutePath)
            }
            cmd.add("--psiphon-dir")
            cmd.add(psiphonDataDir.absolutePath)
            if (psiphonRegion.isNotBlank() && psiphonRegion != "AUTO") {
                cmd.add("--psiphon-region")
                cmd.add(psiphonRegion)
            }
            if (psiphonCdn) {
                cmd.add("--psiphon-mode")
                cmd.add("cdn")
                cmd.add("--psiphon-cdn-sets")
                cmd.add("cloudflare,fastly,cloudfront,psiphon-akamai,curated-fronting")
            } else {
                cmd.add("--psiphon-mode")
                cmd.add("auto")
            }
        }

        if (protocol == "psiphon_only") {
            val cmd = mutableListOf(
                aetherBin.absolutePath,
                "--bind", "127.0.0.1:$SOCKS_PORT",
                "--psiphon-only"
            )
            appendPsiphonFlags(cmd)
            if (directIr) {
                cmd.add("--route-direct")
                cmd.add("private,regexp:\\.ir$")
            }
            return cmd
        }

        val cmd = mutableListOf(aetherBin.absolutePath)
        if (protocol == "aether_psiphon") {
            cmd.add("--bind")
            cmd.add("127.0.0.1:1818")
            cmd.add("--psiphon-bind")
            cmd.add("127.0.0.1:$SOCKS_PORT")
        } else {
            cmd.add("--bind")
            cmd.add("127.0.0.1:$SOCKS_PORT")
        }

        cmd.add("-4")
        cmd.add(if (quickReconnect) "--quick-reconnect" else "--no-quick-reconnect")
        cmd.add("--fragment")
        cmd.add("--fragment-size")
        cmd.add("8-20")
        cmd.add("--fragment-delay")
        cmd.add("4-12")

        when (protocol) {
            "masque_h2" -> {
                cmd.add("--masque")
                cmd.add("--h2")
            }
            "mim" -> {
                cmd.add("--mim")
                if (forceH2) cmd.add("--h2")
            }
            "mim_h2" -> {
                cmd.add("--mim")
                cmd.add("--h2")
            }
            "gool" -> {
                cmd.add("--gool")
            }
            "wg" -> {
                cmd.add("--wg")
                cmd.add("--keepalive")
                cmd.add("15")
            }
            "gool_classic" -> {
                cmd.add("--gool-classic")
                cmd.add("--keepalive")
                cmd.add("15")
            }
            "aether_psiphon" -> {
                cmd.add("--masque")
                if (forceH2) cmd.add("--h2")
                cmd.add("--psiphon")
            }
            "psiphon_aether" -> {
                cmd.add("--masque")
                cmd.add("--h2")
                cmd.add("--psiphon-reverse")
            }
            else -> {
                cmd.add("--masque")
                if (forceH2) cmd.add("--h2")
            }
        }

        if (protocol in listOf("aether_psiphon", "psiphon_aether")) {
            appendPsiphonFlags(cmd)
        }

        if (!sniOverride.isNullOrBlank() && protocol in listOf("masque", "masque_h2", "mim", "mim_h2", "gool", "aether_psiphon", "psiphon_aether")) {
            cmd.add("--masque-sni")
            cmd.add(sniOverride)
        }

        if (stealthTls && protocol !in listOf("wg", "gool_classic")) {
            cmd.add("--enable-grease-sigalgs")
            cmd.add("--tls-cert-compression")
            cmd.add("brotli")
            cmd.add("--tls-alps")
            cmd.add("new")
            if (echAuto) {
                cmd.add("--ech")
                cmd.add("auto")
            } else {
                cmd.add("--enable-ech-grease")
            }
        }

        if (directIr) {
            cmd.add("--route-direct")
            cmd.add("private,regexp:\\.ir$")
        }
        if (avoidIrExit && protocol !in listOf("psiphon_only", "aether_psiphon")) {
            cmd.add("--exit-loc")
            cmd.add("!IR")
        }

        val effectiveScan = when (scan) {
            "balanced", "thorough", "verified", "ironclad" -> scan
            "turbo" -> if (protocol in listOf("masque", "wg", "gool_classic", "mim")) "balanced" else "turbo"
            else -> "balanced"
        }
        cmd.add("--scan")
        cmd.add(effectiveScan)

        val effectiveNoize = when (protocol) {
            "wg", "gool_classic" -> when (noize) {
                "off", "light", "balanced", "firewall", "gfw", "aggressive" -> noize
                else -> "aggressive"
            }
            else -> when (noize) {
                "off", "light", "balanced", "firewall", "gfw", "aggressive" -> noize
                else -> "gfw"
            }
        }
        cmd.add("--noize")
        cmd.add(effectiveNoize)
        return cmd
    }

    private fun launchAetherProcess(cmd: List<String>, workDir: File): Process {
        emitLog("CMD: ${cmd.joinToString(" ")}")
        val psiphonBin = File(applicationInfo.nativeLibraryDir, "libpsiphon.so")
        val pb = ProcessBuilder(cmd).apply {
            directory(workDir)
            redirectErrorStream(true)
            environment()["AETHER_SOCKS"] = "127.0.0.1:$SOCKS_PORT"
            environment()["HOME"] = workDir.absolutePath
            if (psiphonBin.exists()) {
                environment()["AETHER_PSIPHON_BIN"] = psiphonBin.absolutePath
            }
        }
        val proc = pb.start()
        aetherProcess = proc
        try { proc.outputStream.close() } catch (_: Exception) {}

        Thread({
            try {
                proc.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        val trimmed = line.trim()
                        if (trimmed.isNotEmpty()) emitLog("[Aether] $trimmed")
                    }
                }
            } catch (_: Exception) {
            }
        }, "aether-log-reader").start()
        return proc
    }

    private fun terminateAetherProcess() {
        try {
            aetherProcess?.let { p ->
                p.destroy()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && p.isAlive) {
                    p.destroyForcibly()
                }
            }
        } catch (_: Exception) {}
        aetherProcess = null
    }

    private fun startAetherTunnel(
        protocol: String,
        scan: String,
        noize: String,
        mtu: Int,
        fragment: Boolean,
        dnsCsv: String,
        excludedCsv: String,
        psiphonRegion: String = "",
        psiphonCdn: Boolean = false,
        stealthTls: Boolean = true,
        echAuto: Boolean = false,
        directIr: Boolean = true,
        avoidIrExit: Boolean = false
    ) {
        stopping.set(false)
        workerExecutor.execute {
            cleanupCoreOnly()
            isServiceRunning = true
            var activeProtocol = protocol
            emitState("connecting", "شروع هسته ($protocol)...")

            try {
                val aetherBin = File(applicationInfo.nativeLibraryDir, "libaether.so")
                val psiphonBin = File(applicationInfo.nativeLibraryDir, "libpsiphon.so")
                if (!aetherBin.exists()) {
                    throw IllegalStateException("باینری libaether.so در این نسخه نصب نشده است.")
                }
                if (protocol in listOf("psiphon_only", "aether_psiphon", "psiphon_aether") && !psiphonBin.exists()) {
                    throw IllegalStateException("هسته سایفون (libpsiphon.so) در این نسخه موجود نیست.")
                }

                val workDir = File(filesDir, "aether").apply { mkdirs() }

                data class Attempt(
                    val proto: String,
                    val scanMode: String,
                    val quick: Boolean,
                    val sni: String?,
                    val forceCdn: Boolean,
                    val forceH2: Boolean,
                    val useEch: Boolean,
                    val timeoutMs: Long,
                    val label: String
                )
                val attempts = when (protocol) {
                    "masque" -> listOf(
                        Attempt("masque", scan, true, null, false, false, echAuto, 26_000L, "MASQUE H3 (Chrome Stealth + Fragment)"),
                        Attempt("masque", "balanced", false, "consumer-masque.cloudflareclient.com", false, false, echAuto, 26_000L, "MASQUE H3 (SNI جایگزین کلودفلر)"),
                        Attempt("masque_h2", "balanced", false, null, false, true, false, 34_000L, "MASQUE H2 (سوییچ خودکار ضدبسته بودن UDP)")
                    )
                    "mim" -> listOf(
                        Attempt("mim", scan, true, null, false, false, echAuto, 34_000L, "MASQUE-in-MASQUE H3 (دوجداره · IP خارجی)"),
                        Attempt("mim_h2", "balanced", false, null, false, true, false, 40_000L, "MASQUE-in-MASQUE H2 (دوجداره TCP 443)")
                    )
                    "wg" -> listOf(
                        Attempt("wg", scan, true, null, false, false, false, 28_000L, "WARP WG (Aggressive + Keepalive 15s)"),
                        Attempt("wg", "thorough", false, null, false, false, false, 35_000L, "WARP WG (اسکن عمیق بدون کش)")
                    )
                    "psiphon_only" -> buildList {
                        add(Attempt("psiphon_only", scan, true, null, psiphonCdn, false, false, 52_000L, if (psiphonCdn) "سایفون CDN Fronting" else "سایفون هوشمند (Auto + Cache)"))
                        if (!psiphonCdn) {
                            add(Attempt("psiphon_only", scan, false, null, true, false, false, 55_000L, "سایفون (تغییر خودکار به حالت ضدسانسور CDN)"))
                        }
                        add(Attempt("aether_psiphon", "balanced", false, null, true, true, false, 58_000L, "نجات خودکار: زنجیره MASQUE H2 → سایفون"))
                    }
                    "aether_psiphon" -> listOf(
                        Attempt("aether_psiphon", scan, true, null, psiphonCdn, false, echAuto, 55_000L, "زنجیره Aether H3 → سایفون"),
                        Attempt("aether_psiphon", "balanced", false, null, psiphonCdn, true, false, 58_000L, "زنجیره Aether H2 (TCP 443) → سایفون"),
                        Attempt("psiphon_only", scan, false, null, true, false, false, 55_000L, "سایفون CDN (Fallback)")
                    )
                    "psiphon_aether" -> listOf(
                        Attempt("psiphon_aether", scan, true, null, psiphonCdn, true, false, 62_000L, "زنجیره سایفون → Aether MASQUE H2"),
                        Attempt("psiphon_only", scan, false, null, true, false, false, 55_000L, "سایفون CDN (Fallback)")
                    )
                    "rescue" -> listOf(
                        Attempt("masque", "balanced", true, null, false, false, echAuto, 24_000L, "نجات (۱/۴): MASQUE H3"),
                        Attempt("masque_h2", "balanced", false, null, false, true, false, 30_000L, "نجات (۲/۴): MASQUE H2 + Fragment"),
                        Attempt("aether_psiphon", "balanced", false, null, true, true, false, 52_000L, "نجات (۳/۴): زنجیره Aether H2 → سایفون"),
                        Attempt("psiphon_only", "balanced", false, null, true, false, false, 55_000L, "نجات (۴/۴): سایفون CDN Fronting")
                    )
                    else -> listOf(
                        Attempt(protocol, scan, true, null, false, false, echAuto, 42_000L, protocol.uppercase()),
                        Attempt(protocol, "balanced", false, null, false, false, false, 35_000L, "${protocol.uppercase()} (اسکن تازه)")
                    )
                }

                var connectedReady = false
                for ((idx, att) in attempts.withIndex()) {
                    if (stopping.get()) return@execute
                    activeProtocol = att.proto
                    if (idx > 0) {
                        terminateAetherProcess()
                        emitState("connecting", "تلاش مجدد: ${att.label}...")
                    }
                    val cmd = buildAetherCommand(
                        aetherBin, psiphonBin, workDir,
                        att.proto, att.scanMode, noize, att.quick, att.sni,
                        psiphonRegion, att.forceCdn, att.forceH2,
                        stealthTls, att.useEch, directIr, avoidIrExit
                    )
                    val proc = launchAetherProcess(cmd, workDir)
                    if (waitForSocksReady(proc, timeoutMs = att.timeoutMs)) {
                        connectedReady = true
                        break
                    }
                    terminateAetherProcess()
                }

                if (!connectedReady || stopping.get()) {
                    if (!stopping.get()) {
                        throw IllegalStateException("هسته Aether نتوانست درگام سالم کلودفلر پیدا کند یا بسته شد.")
                    }
                    return@execute
                }

                // Build TUN interface
                val builder = Builder()
                    .setSession("NovaGuard Aether")
                    .setMtu(mtu)
                    .addAddress("198.18.0.1", 24)
                    .addRoute("0.0.0.0", 0)

                val dnsList = dnsCsv.split(",")
                    .map { it.trim() }
                    .filter { it.matches(Regex("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) }
                if (dnsList.isNotEmpty()) {
                    dnsList.forEach { builder.addDnsServer(it) }
                } else {
                    builder.addDnsServer("1.1.1.1")
                    builder.addDnsServer("8.8.8.8")
                }

                // Prevent routing loop: Aether sockets must bypass TUN
                try {
                    builder.addDisallowedApplication(packageName)
                } catch (_: Exception) {
                }

                excludedCsv.split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() && it != packageName }
                    .forEach { pkg ->
                        try { builder.addDisallowedApplication(pkg) } catch (_: Exception) {}
                    }

                val pfd = builder.establish()
                    ?: throw IllegalStateException("ایجاد رابط TUN توسط سیستم‌عامل رد شد.")
                tunInterface = pfd

                val yamlFile = File(filesDir, "tproxy.yml")
                yamlFile.writeText(
                    """
                    tunnel:
                      name: tun0
                      mtu: $mtu
                      multi-queue: false
                      ipv4: 198.18.0.1
                      icmp: 'reply'
                    socks5:
                      port: $SOCKS_PORT
                      address: 127.0.0.1
                      udp: 'udp'
                    misc:
                      task-stack-size: 86016
                      tcp-buffer-size: 65536
                      udp-recv-buffer-size: 524288
                      connect-timeout: 10000
                      tcp-read-write-timeout: 300000
                      udp-read-write-timeout: 60000
                    """.trimIndent()
                )

                val started = TProxyService.TProxyStartService(yamlFile.absolutePath, pfd.fd)
                if (!started) {
                    throw IllegalStateException("راه‌اندازی موتور hev-socks5-tunnel ناموفق بود.")
                }

                updateNotification("متصل · Aether (${activeProtocol.uppercase()})")
                val extraNote = if (protocol == "masque" && activeProtocol == "masque_h2") {
                    "تونل برقرار شد ✅ (سوییچ خودکار به MASQUE H2 به‌دلیل محدودیت UDP)"
                } else {
                    "تونل Aether (${activeProtocol.uppercase()}) برقرار شد ✅"
                }
                emitState("connected", extraNote)
                startStatsPolling()

            } catch (e: Exception) {
                if (!stopping.get()) {
                    emitLog("ERROR: ${e.message}")
                    stopAetherTunnel("خطا در Aether: ${e.message ?: "نامشخص"}")
                }
            }
        }
    }

    private fun waitForSocksReady(proc: Process, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline && !stopping.get()) {
            if (!proc.isAlive) return false
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress("127.0.0.1", SOCKS_PORT), 350)
                }
                return true
            } catch (_: Exception) {
                try { Thread.sleep(250) } catch (_: InterruptedException) { return false }
            }
        }
        return false
    }

    private fun startStatsPolling() {
        stopStatsPolling()
        statsTask = statsScheduler.scheduleAtFixedRate({
            try {
                if (!isServiceRunning || stopping.get()) return@scheduleAtFixedRate
                if (aetherProcess?.isAlive == false) {
                    stopAetherTunnel("پروسه هسته Aether متوقف شد.")
                    return@scheduleAtFixedRate
                }
                val stats = TProxyService.TProxyGetStats()
                if (stats.size >= 4) {
                    val txBytes = stats[1]
                    val rxBytes = stats[3]
                    sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
                        putExtra(EVENT_TYPE, "stats")
                        putExtra(EVENT_RX, rxBytes)
                        putExtra(EVENT_TX, txBytes)
                    })
                }
            } catch (_: Exception) {
            }
        }, 400, 1000, TimeUnit.MILLISECONDS)
    }

    private fun stopStatsPolling() {
        statsTask?.cancel(false)
        statsTask = null
    }

    private fun cleanupCoreOnly() {
        stopStatsPolling()
        try {
            if (TProxyService.TProxyIsRunning()) {
                TProxyService.TProxyStopService()
            }
        } catch (_: Exception) {
        }
        try { tunInterface?.close() } catch (_: Exception) {}
        tunInterface = null
        try {
            aetherProcess?.let { p ->
                p.destroy()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && p.isAlive) {
                    p.destroyForcibly()
                }
            }
        } catch (_: Exception) {}
        aetherProcess = null
    }

    private fun stopAetherTunnel(reason: String) {
        if (stopping.getAndSet(true)) return
        workerExecutor.execute {
            cleanupCoreOnly()
            isServiceRunning = false
            emitState("disconnected", reason)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun emitState(state: String, msg: String?) {
        currentState = state
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "state")
            putExtra(EVENT_STATE, state)
            if (msg != null) putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun emitLog(msg: String) {
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "log")
            putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                CHANNEL_ID,
                "NovaGuard Aether VPN",
                NotificationManager.IMPORTANCE_LOW
            )
            nm?.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pendingOpen = PendingIntent.getActivity(this, 0, openIntent, flags)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("NovaGuard")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pendingOpen)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.notify(NOTIF_ID, buildNotification(text))
        } catch (_: Exception) {
        }
    }

    override fun onRevoke() {
        stopAetherTunnel("مجوز VPN لغو شد.")
        super.onRevoke()
    }

    override fun onDestroy() {
        stopping.set(true)
        cleanupCoreOnly()
        isServiceRunning = false
        currentState = "disconnected"
        workerExecutor.shutdownNow()
        statsScheduler.shutdownNow()
        super.onDestroy()
    }
}
