-keep class com.tunweb.wireguard.MainActivity$AndroidVpnBridge { *; }
-keepclassmembers class com.tunweb.wireguard.MainActivity$AndroidVpnBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.wireguard.android.** { *; }
