# TunWeb WireGuard — پروژه آماده تبدیل HTML به APK واقعی

این پروژه طوری طراحی شده که رابط کاربری HTML/CSS/JS شما (`app/src/main/assets/www/index.html`) از طریق پل ارتباطی `AndroidVpn` مستقیماً به کتابخانه رسمی **`com.wireguard.android:tunnel` (`GoBackend`)** متصل شود و یک **APK واقعی و بهینه** تولید کند.

## چرا تبدیل مستقیم HTML با مبدل‌های معمولی کار نمی‌کند؟
مبدل‌های ساده (مثل Website-to-APK) فقط یک مرورگر WebView می‌سازند و اجازه دسترسی به `VpnService` اندروید و هسته WireGuard را ندارند. در این پروژه:
- فایل HTML در مسیر `app/src/main/assets/www/index.html` قرار دارد (کاملاً بدون فریم‌ورک سنگین و آفلاین).
- فایل `MainActivity.kt` پل `window.AndroidVpn` را به WebView تزریق می‌کند.
- کتابخانه رسمی `com.wireguard.android:tunnel` هسته `libwg-go.so` را در APK قرار می‌دهد و ترافیک واقعی گوشی را تونل می‌کند.
- با تنظیم `minifyEnabled = true`، `shrinkResources = true` و `abiFilters`/`splits` حجم APK برای هر معماری پردازنده (مثل `arm64-v8a`) کاملاً بهینه می‌شود.

## روش ۱: ساخت APK در Android Studio
1. پوشه `wireguard-apk-project` را در **Android Studio** باز کنید.
2. صبر کنید Gradle Sync تمام شود.
3. از منوی بالا `Build > Build Bundle(s) / APK(s) > Build APK(s)` را بزنید.
4. فایل‌های خروجی APK در مسیر `app/build/outputs/apk/` آماده نصب روی گوشی هستند.

## روش ۲: ساخت خودکار APK بدون نصب Android Studio (با GitHub Actions)
1. محتوای پوشه `wireguard-apk-project` را در یک ریپازیتوری گیت‌هاب آپلود کنید.
2. فایل `.github/workflows/build-apk.yml` به‌صورت خودکار APK را بیلد می‌کند.
3. از تب **Actions** فایل `TunWeb-WireGuard-APK` را دانلود و روی گوشی نصب کنید.
